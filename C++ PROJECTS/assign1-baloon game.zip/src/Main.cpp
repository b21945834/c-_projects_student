#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>


using namespace std;
ifstream input1;
ifstream input2;
string gridS;
string line;
int gridSize;
int areaSize;
int baloonRow;
int baloonColumn;
int baloonNumber;
vector<vector<int>> allBaloons;
vector<vector<int>> grid(gridSize,vector<int>(gridSize));
vector<vector<int>> baloonsToBeExposed;
vector<vector<int>> bombedList;
int bombedValue;
int Points;

void exposeBaloons(vector<vector<int>> &grid,int baloonRow,int baloonColumn);


void printGrid(vector<vector<int>> &grid){
    for(vector<int> row:grid){
        for(int col:row){
            cout<<col<<" ";
        }
        cout<<endl;
    }
}
void boom(vector<vector<int>> &area){
    for(vector<int> oneBomb:bombedList){
        area[oneBomb[0]][oneBomb[1]] = 0;
        Points += bombedValue;
    }
}
void toBeBombed(vector<vector<int>> &area, int bombedRow, int bombedColumn){
    bombedValue = area[bombedRow][bombedColumn];
    int initial = bombedRow;
    vector<int> ownBomb;
    ownBomb.push_back(bombedRow);
    ownBomb.push_back(bombedColumn);
    bombedList.push_back(ownBomb);
    for (int i = areaSize-1; i >= 0 ; --i) {
        vector<int> initialList;
        if(area[i][bombedColumn]==bombedValue && i !=bombedRow ){
            initialList.push_back(i);
            initialList.push_back(bombedColumn);
            bombedList.push_back(initialList);
        }
    }
    for (int i = areaSize-1; i >=0 ; --i) {
        vector<int> initialList;
        if(area[bombedRow][i] == bombedValue && i != bombedColumn){
            initialList.push_back(bombedRow);
            initialList.push_back(i);
            bombedList.push_back(initialList);
        }
    }
    initial = 0;
    while(bombedRow - initial !=0 && initial + bombedColumn != areaSize-1){
        initial++;
    }
    while(bombedColumn+initial>=0 && bombedRow-initial<areaSize){
        vector<int> initialList;
        if(initial!=0 && area[bombedRow-initial][bombedColumn+initial] == bombedValue){
            initialList.push_back(bombedRow-initial);
            initialList.push_back(bombedColumn+initial);
            bombedList.push_back(initialList);
        }
        initial--;
    }
    initial = 0;
    while(bombedRow-initial != 0 && bombedColumn-initial!=0 ){
        initial++;
    }
    while(bombedColumn-initial<areaSize && bombedRow-initial<areaSize  ){
        vector<int> initialList;
        if(initial!=0&& area[bombedRow-initial][bombedColumn-initial] == bombedValue){
            initialList.push_back(bombedRow-initial);
            initialList.push_back(bombedColumn-initial);
            bombedList.push_back(initialList);
        }
        initial--;
    }

}



void linkControl(vector<vector<int>> &grid, int movedRow,int movedColumn,int oldRow,int oldColumn){
    vector<int> oneBaloon;
    //sağ
    if(oldColumn-1 != movedColumn) {
        if (movedColumn + 1 < gridSize) {
            if (grid[movedRow][movedColumn + 1] == grid[movedRow][movedColumn]) {
                oneBaloon.push_back(movedRow);
                oneBaloon.push_back(movedColumn + 1);
                baloonsToBeExposed.push_back(oneBaloon);
                oneBaloon.clear();
                linkControl(grid, movedRow, movedColumn + 1,movedRow,movedColumn);
            }
        }
    }
    //sol
    if(oldColumn+1!=movedColumn){
        if(movedColumn-1>=0){
            if(grid[movedRow][movedColumn] == grid[movedRow][movedColumn-1]){
                oneBaloon.push_back(movedRow);
                oneBaloon.push_back(movedColumn-1);
                baloonsToBeExposed.push_back(oneBaloon);
                oneBaloon.clear();
                linkControl(grid,movedRow,movedColumn-1,movedRow,movedColumn);
            }
        }
    }
    //AŞAĞI
    if(movedRow+1!=oldRow) {
        if (movedRow + 1 < gridSize) {
            if (grid[movedRow][movedColumn] == grid[movedRow + 1][movedColumn]) {
                oneBaloon.push_back(movedRow + 1);
                oneBaloon.push_back(movedColumn);
                baloonsToBeExposed.push_back(oneBaloon);
                oneBaloon.clear();
                linkControl(grid, movedRow+1, movedColumn,movedRow,movedColumn);
            }
        }
    }
    //yukarı
    if(oldRow+1!=movedRow) {
        if (movedRow - 1 >= 0) {
            if (grid[movedRow][movedColumn] == grid[movedRow-1][movedColumn]) {
                oneBaloon.push_back(movedRow - 1);
                oneBaloon.push_back(movedColumn);
                baloonsToBeExposed.push_back(oneBaloon);
                oneBaloon.clear();
                linkControl(grid, movedRow - 1, movedColumn,movedRow,movedColumn);
            }
        }
    }
}
void exposeBaloons(vector<vector<int>> &grid, int baloonRow, int baloonColumn){
    for (int i = 0; i < baloonsToBeExposed.size(); ++i) {
        vector<int> exposeThat = baloonsToBeExposed[i];
        grid[exposeThat[0]][exposeThat[1]] = 0;
    }
    baloonsToBeExposed.clear();
    grid[baloonRow][baloonColumn] += 1;
    linkControl(grid,baloonRow,baloonColumn,baloonRow,baloonColumn);
}

int main(int argc, char *argv[]) {
    //PART1 BELOW HERE.
    freopen(argv[3],"w",stdout);
    input1.open(argv[1]);
    if (input1.is_open()){
        input1 >> gridS;
        stringstream geek(gridS);
        geek >> gridSize;
        vector<vector<int>> allBaloons;
        vector<vector<int>> grid(gridSize,vector<int>(gridSize));
        while(getline(input1,line)){
            //ONE LINE IS EXUCUTED BELOW HERE
            stringstream toBeSplitted(line);
            vector<int> baloonInfo;
            int temp;
            while(toBeSplitted>>temp){
                baloonInfo.push_back(temp);
            }
            if(baloonInfo.size()==3){
                allBaloons.push_back(baloonInfo);
            }
        }
        for (int i = 0; i < allBaloons.size(); ++i) {
            baloonsToBeExposed.clear();
            int baloonType = allBaloons[i][0];
            baloonRow = allBaloons[i][1];
            baloonColumn = allBaloons[i][2];
            grid[baloonRow][baloonColumn] = baloonType;
            linkControl(grid,baloonRow,baloonColumn,baloonRow,baloonColumn);
            while(baloonsToBeExposed.size()>=2){
                exposeBaloons(grid,baloonRow,baloonColumn);
            }
        }
        cout<<"PART 1:\n";
        printGrid(grid);}
    //PART2 BELOW HERE.
    input2.open(argv[2]);
    if(input2.is_open()){
        string line;
        input2 >> line;
        stringstream geek(line);
        geek>>areaSize;
        vector<vector<int>> commands;
        vector<vector<int>> area(areaSize,vector<int>(areaSize));
        while(getline(input2, line)){
            stringstream toBeSplitted(line);
            vector<int> oneline;
            int singleInt;
            while(toBeSplitted>>singleInt){
                oneline.push_back(singleInt);
            }
            if(oneline.size()>0){
                commands.push_back(oneline);
            }
        }
        int neededRow = 0;
        for(vector<int> command:commands) {
            if(command.size()==areaSize){
                int neededColumn = 0;
                for(int value:command){
                    area[neededRow][neededColumn] = value;
                    neededColumn += 1;
                }
            }
            else if(command.size()==2){
                bombedList.clear();
                toBeBombed(area,command[0],command[1]);
                boom(area);
            }
            neededRow += 1;
        }
        cout<<"\nPART 2:\n";
        printGrid(area);
        cout<<"Final Point: "<<Points<<"p"<<endl;
    }

    return 0;
}
