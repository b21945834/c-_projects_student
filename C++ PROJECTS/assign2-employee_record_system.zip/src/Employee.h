//
// Created by 90543 on 29.11.2021.
//

#ifndef ASSIGNMENT2_EMPLOYEE_H
#define ASSIGNMENT2_EMPLOYEE_H
#include "Date.h"
#include <iostream>

using namespace std;

class Employee {

public:
    Employee();

    Employee(int number, int type, string name, string surname, string title, float salaryCoef,
             Date birthDate, Date appointment, int serviceLength);

    Employee(int number, int type, string name, string surname, string title, float salaryCoef,
             Date birthDate,  Date appointment);

    friend ostream &operator<<(ostream &os, const Employee &employee);

public:
    int getNumber() const;

    void setNumber(int number);

    const string &getName() const;

    void setName(const string &name);

    const string &getSurname() const;

    void setSurname(const string &surname);

    const string &getTitle() const;

    void setTitle(const string &title);

    float getSalaryCoef() const;

    void setSalaryCoef(float salaryCoef);

    const Date &getBirthDate() const;

    void setBirthDate(const Date &birthDate);

    const Date &getAppointmentDate() const;

    void setAppointmentDate(const Date &appointmentDate);

    int getServiceLength() const;

    void setServiceLength(int serviceLength);

    int getType() const;

    void setType(int type);

protected:
    int Number;
    string Name;
    string Surname;
    string Title;
    float SalaryCoef;
    Date BirthDate;
    Date AppointmentDate;
    int ServiceLength;
    int Type;
};


#endif //ASSIGNMENT2_EMPLOYEE_H
