#include <iostream>
#include "Employee.h"
#include "PermanentEmployee.h"
#include "TemporaryEmployee.h"
#include "Employee.h"
#include "algorithm"
#include "CircularArrayLinkedList.h"
#include "DoubleDynamicLinkedList.h"
#include "Date.h"
#include "string"
#include "vector"
#include "sstream"


using namespace std;
CircularArrayLinkedList temporaryEmployees = CircularArrayLinkedList();
DoubleDynamicLinkedList permanentEmployees = DoubleDynamicLinkedList();




vector<int> employeeNumbers;
void functionOne(){
    int number,type;
    string name,surname,title,birthDateS,appointmentDateS;
    float salaryCoef;
    cout<<"Please type the employee number"<<endl;
    cin>>number;
    if (!count(employeeNumbers.begin(),employeeNumbers.end(),number)) {
        cout << "Type the employee type" << endl;
        cin >> type;
        cout << "Type the Name" << endl;
        cin >> name;
        cout << "Type surname" << endl;
        cin >> surname;
        cout << "Type title" << endl;
        cin >> title;
        cout << "Type salary coefficent" << endl;
        cin >> salaryCoef;
        cout << "Type birth date" << endl;
        cin >> birthDateS;
        cout << "Type appointment date" << endl;
        cin >> appointmentDateS;
        vector<string> DateVector;
        string dayS = birthDateS.substr(0, 2);
        string monthS = birthDateS.substr(3, 2);
        string yearS = birthDateS.substr(6, 4);
        Date birthDate = Date(stoi(dayS), stoi(monthS), stoi(yearS));
        dayS = appointmentDateS.substr(0, 2);
        monthS = appointmentDateS.substr(3, 2);
        yearS = appointmentDateS.substr(6, 4);
        Date appointmentDate = Date(stoi(dayS), stoi(monthS), stoi(yearS));
        if (type == 0) {
            TemporaryEmployee employee = TemporaryEmployee(number, type, name, surname, title, salaryCoef,
                                                           birthDate, appointmentDate);
            temporaryEmployees.insert(employee);
            employeeNumbers.push_back(employee.getNumber());

        } else {
            PermanentEmployee employee = PermanentEmployee(number, type, name, surname, title, salaryCoef,
                                                           birthDate, appointmentDate);
            permanentEmployees.insert(employee);
            employeeNumbers.push_back(employee.getNumber());
        }
    }
}

void functionTwo(){
    int number,type,serviceLength;
    string name,surname,title,birthDateS,appointmentDateS;
    float salaryCoef;
    cout<<"Please type the employee number"<<endl;
    cin>>number;
    if (!count(employeeNumbers.begin(),employeeNumbers.end(),number)) {
        cout << "Type the employee type" << endl;
        cin >> type;
        cout << "Type the Name" << endl;
        cin >> name;
        cout << "Type surname" << endl;
        cin >> surname;
        cout << "Type title" << endl;
        cin >> title;
        cout << "Type salary coefficent" << endl;
        cin >> salaryCoef;
        cout << "Type birth date" << endl;
        cin >> birthDateS;
        cout << "Type appointment date" << endl;
        cin >> appointmentDateS;
        cout<<"Type length of service days"<<endl;
        cin>>serviceLength;
        vector<string> DateVector;
        string dayS = birthDateS.substr(0, 2);
        string monthS = birthDateS.substr(3, 2);
        string yearS = birthDateS.substr(6, 4);
        Date birthDate = Date(stoi(dayS), stoi(monthS), stoi(yearS));
        dayS = appointmentDateS.substr(0, 2);
        monthS = appointmentDateS.substr(3, 2);
        yearS = appointmentDateS.substr(6, 4);
        Date appointmentDate = Date(stoi(dayS), stoi(monthS), stoi(yearS));
        if (type == 0) {
            TemporaryEmployee employee = TemporaryEmployee(number, type, name, surname, title, salaryCoef,
                                                           birthDate, appointmentDate,serviceLength);
            temporaryEmployees.insert(employee);
            employeeNumbers.push_back(employee.getNumber());

        } else {
            PermanentEmployee employee = PermanentEmployee(number, type, name, surname, title, salaryCoef,
                                                           birthDate, appointmentDate,serviceLength);
            permanentEmployees.insert(employee);
            employeeNumbers.push_back(employee.getNumber());
        }
    }
}

void functionThree(){
    int number;
    cout<<"Please type employee number"<<endl;
    cin>>number;
    if(!count(employeeNumbers.begin(),employeeNumbers.end(),number)){
        int indexIfThereIs = temporaryEmployees.searchEmployee(number);
        if(indexIfThereIs!=-1){
            temporaryEmployees.updateThese(indexIfThereIs);
        }
        else {
            struct Node* toBeUpdated = permanentEmployees.findThatEmployee(number);
            permanentEmployees.UpdateThese(toBeUpdated);
        }
    }
}
void functionFive(){
    int wantToPrint;
    cout<<"Type number of employee you want to list informations of"<<endl;
    cin>> wantToPrint;
    int index = temporaryEmployees.searchEmployee(wantToPrint);
    if (index!=-1){
        temporaryEmployees.printEmployee(index);
    } else{
        struct Node* toBePrinted = permanentEmployees.findThatEmployee(wantToPrint);
        permanentEmployees.printEmployee(toBePrinted);
    }
}

void functionFour(){
    int wantToDelete;
    cout<<"Type number of employee you want to delete"<<endl;
    cin>>wantToDelete;
    if(!count(employeeNumbers.begin(),employeeNumbers.end(),wantToDelete)){
        if(temporaryEmployees.searchEmployee(wantToDelete)!=-1){
            temporaryEmployees.deleteThatNumber(wantToDelete);
        } else{
            permanentEmployees.deleteNode(wantToDelete);
        }
    }
}


int main() {
    while (true) {
        string function;
        cout << "TYPE FUNC" << endl;
        cin >> function;
        if (function == "1") {
            functionOne();
        }
        else if (function == "2") {
            functionTwo();
        } else if (function == "3"){
            functionThree();
        } else if (function == "4"){
            functionFour();
        }
        else if (function == "5"){
            functionFive();
        }
    }
}
