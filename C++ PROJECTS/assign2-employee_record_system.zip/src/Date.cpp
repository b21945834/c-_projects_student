//
// Created by 90543 on 29.11.2021.
//

#include "Date.h"
using namespace std;
#include <iostream>

Date::Date(int da, int mo, int ye) {
    day = da;
    month = mo;
    year = ye;

}

Date::Date() {

}
