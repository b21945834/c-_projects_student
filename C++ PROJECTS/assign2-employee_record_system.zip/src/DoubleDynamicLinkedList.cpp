//
// Created by 90543 on 29.11.2021.
//

#include "DoubleDynamicLinkedList.h"

#include <utility>
#include "iostream"

using namespace std;

struct Node{
public:

    Node* prev;
    PermanentEmployee data;
    Node* next;
};



struct Node* getNode(){
    struct Node* newNode = new Node;
    newNode->prev = nullptr;
    newNode->next = nullptr;

    return newNode;
}

void DoubleDynamicLinkedList::insert(PermanentEmployee x) {

    struct Node* newnode = getNode();

    newnode->data = std::move(x);
    newnode->next = head;

    if(head != NULL){
        head->prev = newnode ;
    }
    head = newnode;
}

struct Node* DoubleDynamicLinkedList::findThatEmployee(int number){
    if(head->data.getNumber()==number){
        return head;
    }
    struct Node* mover = head->next;
    while(mover->data.getNumber()!=number){
        mover = mover->next;
    }
    if(mover->data.getNumber()==number){
        return mover;
    }
}

void DoubleDynamicLinkedList::printEmployee(struct Node* printed){
    cout<<printed->data<<endl;
}

void DoubleDynamicLinkedList::UpdateThese(struct Node* updateThat){
    string newTitle;float newCoef;
    cout<<"Please type the new title of employee"<<endl;
    cin>>newTitle;
    updateThat->data.setTitle(newTitle);
    cout<<"Please type the new salary coefficient of employee";
    cin>>newCoef;
    updateThat->data.setSalaryCoef(newCoef);
}


void DoubleDynamicLinkedList::deleteNode(int number){
    struct Node* toBeDeleted = findThatEmployee(number);
    if(toBeDeleted->prev == nullptr){
        toBeDeleted->next->prev = nullptr;
        head = toBeDeleted->next;
        toBeDeleted->next = nullptr;
        delete toBeDeleted;
    } else if (toBeDeleted->next== nullptr){
        toBeDeleted->prev->next = nullptr;
        toBeDeleted->prev = nullptr;
        delete toBeDeleted;
    } else{
        toBeDeleted->prev->next = toBeDeleted->next;
        toBeDeleted->next->prev = toBeDeleted->prev;
        toBeDeleted->next = nullptr;
        toBeDeleted->prev = nullptr;
        delete toBeDeleted;
    }
}



DoubleDynamicLinkedList::DoubleDynamicLinkedList() {
    head = nullptr;
}
