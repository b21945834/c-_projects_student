//
// Created by 90543 on 29.11.2021.
//
#include <sstream>
#include "TemporaryEmployee.h"
#include <iostream>
using namespace std;

