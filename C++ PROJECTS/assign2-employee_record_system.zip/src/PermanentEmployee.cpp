//
// Created by 90543 on 29.11.2021.
//

#include "PermanentEmployee.h"


