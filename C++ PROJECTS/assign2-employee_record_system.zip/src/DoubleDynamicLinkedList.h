//
// Created by 90543 on 29.11.2021.
//

#ifndef ASSIGNMENT2_DOUBLEDYNAMICLINKEDLIST_H
#define ASSIGNMENT2_DOUBLEDYNAMICLINKEDLIST_H
using namespace std;
#include "iostream"
#include "PermanentEmployee.h"
struct Node;
class DoubleDynamicLinkedList {
public:
    DoubleDynamicLinkedList();
    void insert(PermanentEmployee x);
    void deleteNode(int number);
    struct Node* findThatEmployee(int k);
    struct Node* head;
    void UpdateThese(struct Node* u);
    void printEmployee(struct Node*);

};
class Node;


#endif //ASSIGNMENT2_DOUBLEDYNAMICLINKEDLIST_H
