//
// Created by 90543 on 29.11.2021.
//
using namespace std;
#include "CircularArrayLinkedList.h"
#include <iostream>
#include <utility>
#include <vector>

struct Node {
    TemporaryEmployee data;
    int next;
};


struct Node node[20];


int p;
int avail;
vector<int> availables = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19};


int CircularArrayLinkedList::getnode() {
    int avail = availables[0];
    vector<int>::iterator it;
    it = availables.begin();
    availables.erase(it);

    p = avail;
    return p;
}

CircularArrayLinkedList::CircularArrayLinkedList() {
    lastOfTemporary=-1;
}



void CircularArrayLinkedList::freenode(int p)
{
    node[p].next = avail;
    avail = p;
}
void CircularArrayLinkedList::insert(TemporaryEmployee employee)
{
    int q;
    if(availables.empty()){
        return;
    }
    q = getnode();
    struct Node newnode;
    newnode.data = std::move(employee);
    if(lastOfTemporary==-1){
        newnode.next = 0;
        lastOfTemporary = 0;
    }
    else{
        newnode.next = node[lastOfTemporary].next;
        node[lastOfTemporary].next = q;
        lastOfTemporary = q;
    }
    node[q] = newnode;
}
void CircularArrayLinkedList::deleteThatNumber(int number)
{
    int a;
    int mover = node[lastOfTemporary].next;
    while(mover != lastOfTemporary){
        if(node[mover].data.getNumber()==number){
            a = lastOfTemporary;
            break;
        }
        if(node[node[mover].next].data.getNumber()==number){
            a = mover;
            break;
        }
        mover = node[mover].next;
    }
    int q;
    q = node[a].next;
    node[a].next = node[q].next;
    node[q].next = -1;
    if(q==lastOfTemporary){
        a = lastOfTemporary;
    }
    availables.push_back(q);
}

void CircularArrayLinkedList::printEmployee(int index){
    cout<<node[index].data<<endl;
}

int CircularArrayLinkedList::searchEmployee(int number){
    if(node[lastOfTemporary].data.getNumber()==number){
        return lastOfTemporary;
    }
    int mover = node[lastOfTemporary].next;
    while(mover!=lastOfTemporary){
        if(node[mover].data.getNumber() == number){
            return mover;
        }
        mover = node[mover].next;
    }
    return -1;
}
void CircularArrayLinkedList::updateThese(int index){
    string newTitle;float newCoef;
    cout<<"Please type the new title of employee"<<endl;
    cin>>newTitle;
    node[index].data.setTitle(newTitle);
    cout<<"Please type the new salary coefficient of employee";
    cin>>newCoef;
    node[index].data.setSalaryCoef(newCoef);
}

