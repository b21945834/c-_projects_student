//
// Created by 90543 on 29.11.2021.
//

#ifndef ASSIGNMENT2_PERMANENTEMPLOYEE_H
#define ASSIGNMENT2_PERMANENTEMPLOYEE_H
using namespace std;
#include <iostream>
#include "Employee.h"

class PermanentEmployee : public Employee{

public:
    PermanentEmployee() : Employee() {}
    PermanentEmployee(int number1, int type1, string name1, string surname1, string title1, float salaryCoef1,
                      Date birthDate1, Date appointment1) : Employee(number1, type1, name1, surname1, title1, salaryCoef1, birthDate1, appointment1){}


    PermanentEmployee(int number1, int type1, string name1, string surname1, string title1, float salaryCoef1,
                      Date birthDate1, Date appointment1, int serviceLength1) : Employee(number1, type1, name1, surname1, title1, salaryCoef1, birthDate1, appointment1, serviceLength1){}

};


#endif //ASSIGNMENT2_PERMANENTEMPLOYEE_H
