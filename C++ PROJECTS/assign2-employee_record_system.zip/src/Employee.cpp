//
// Created by 90543 on 29.11.2021.
//

#include "Employee.h"
using namespace std;
#include <iostream>


int Employee::getNumber() const {
    return Number;
}

void Employee::setNumber(int number) {
    Number = number;
}

const string &Employee::getName() const {
    return Name;
}

void Employee::setName(const string &name) {
    Name = name;
}

const string &Employee::getSurname() const {
    return Surname;
}

void Employee::setSurname(const string &surname) {
    Surname = surname;
}

const string &Employee::getTitle() const {
    return Title;
}

void Employee::setTitle(const string &title) {
    Title = title;
}

float Employee::getSalaryCoef() const {
    return SalaryCoef;
}

void Employee::setSalaryCoef(float salaryCoef) {
    SalaryCoef = salaryCoef;
}

const Date &Employee::getBirthDate() const {
    return BirthDate;
}

void Employee::setBirthDate(const Date &birthDate) {
    BirthDate = birthDate;
}

const Date &Employee::getAppointmentDate() const {
    return AppointmentDate;
}

void Employee::setAppointmentDate(const Date &appointmentDate) {
    AppointmentDate = appointmentDate;
}

int Employee::getServiceLength() const {
    return ServiceLength;
}

void Employee::setServiceLength(int serviceLength) {
    ServiceLength = serviceLength;
}

int Employee::getType() const {
    return Type;
}

void Employee::setType(int type) {
    Type = type;
}

Employee::Employee(int number, int type, string name, string surname, string title, float salaryCoef, Date birthDate,
                   Date appointment) {
    Number =number;
    Type = type;
    Name = name;
    Surname = surname;
    Title = title;
    SalaryCoef = salaryCoef;
    BirthDate = birthDate;
    AppointmentDate = appointment;

}

Employee::Employee(int number, int type, string name, string surname, string title, float salaryCoef, Date birthDate,
                   Date appointment, int serviceLength) {
    Number =number;
    Type = type;
    Name = name;
    Surname = surname;
    Title = title;
    SalaryCoef = salaryCoef;
    BirthDate = birthDate;
    AppointmentDate = appointment;
    ServiceLength = serviceLength;
}

Employee::Employee() {
}

ostream &operator<<(ostream &os, const Employee &employee) {
    os << "Number: " << employee.Number << " Name: " << employee.Name << " Surname: " << employee.Surname << " Title: "
       << employee.Title << " SalaryCoef: " << employee.SalaryCoef << " BirthDate: " << employee.BirthDate.day <<"-"<<employee.BirthDate.month<<"-"<<employee.BirthDate.year
       << " AppointmentDate: " << employee.AppointmentDate.day<< "-"<<employee.AppointmentDate.month<<"-"<<employee.AppointmentDate.year << " ServiceLength: " << employee.ServiceLength << " Type: "
       << employee.Type;
    return os;
}



