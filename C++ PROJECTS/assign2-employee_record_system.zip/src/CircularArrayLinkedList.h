//
// Created by 90543 on 29.11.2021.
//

#ifndef ASSIGNMENT2_CIRCULARARRAYLINKEDLIST_H
#define ASSIGNMENT2_CIRCULARARRAYLINKEDLIST_H
#include "iostream"
#include "TemporaryEmployee.h"
#include "Employee.h"
#include <vector>
#pragma once


using namespace std;

class CircularArrayLinkedList {
public:
    CircularArrayLinkedList();
    int lastOfTemporary;
    int getnode();
    vector<int> availables = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19};
    void freenode(int p);
    void insert(TemporaryEmployee x);
    void deleteThatNumber(int n);
    int searchEmployee(int f);
    void updateThese(int k);
    void printEmployee(int index);

};






#endif //ASSIGNMENT2_CIRCULARARRAYLINKEDLIST_H
