//
// Created by 90543 on 29.11.2021.
//
using namespace std;
#include <iostream>
#ifndef ASSIGNMENT2_DATE_H
#define ASSIGNMENT2_DATE_H


class Date {
public:
    int day;
    int month;
    int year;
    Date();
    Date(int da,int mo,int ye);
};


#endif //ASSIGNMENT2_DATE_H
