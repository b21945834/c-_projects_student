#include <iostream>
#include <fstream>
#include "vector"
#include "algorithm"
const int ALP_SIZE = 26;
using namespace std;
string output;


struct TrieNode
{
    struct TrieNode *children[ALP_SIZE];
    bool isEndOfWord;
    string english;
    int noUsage;
    TrieNode();
};
vector<TrieNode*> deleteList;

TrieNode::TrieNode() {
}

struct TrieNode *getNode()
{
    struct TrieNode *pNode =  new TrieNode;

    pNode->isEndOfWord = false;
    pNode->english = "-1";
    pNode->noUsage= 0;

    for (int i = 0; i < ALP_SIZE; i++)
        pNode->children[i] = NULL;

    return pNode;
}

string insert(struct TrieNode *root, string key,string eng)
{
    struct TrieNode *nodeMover = root;

    for (int i = 0; i < key.length(); i++)
    {
        int index = key[i] - 'a';
        if (!nodeMover->children[index]) {
            nodeMover->children[index] = getNode();
        }
        nodeMover = nodeMover->children[index];
        nodeMover->noUsage += 1;
    }
    if(nodeMover->english=="-1"){
        nodeMover->english = eng;
        nodeMover->isEndOfWord = true;
        return "success";
    }
    else if(nodeMover->english==eng){
        return "already";
    }
    else{
        nodeMover->english = eng;
        nodeMover->isEndOfWord = true;
        return "updated";
    }
}

string search(struct TrieNode *root, string key)
{
    int i;
    int index;
    struct TrieNode *pCrawl = root;

    for (i = 0; i < key.length(); i++)
    {
        index = key[i] - 'a';
        if (!pCrawl->children[index])
            if(i ==0){
                return "noRecord";
            } else{
                return "incorrect";
            }
        pCrawl = pCrawl->children[index];
    }

    if(pCrawl->isEndOfWord){
        return pCrawl->english;
    } else{
        return "notEnough";
    }
}

bool isEmpty(TrieNode* root)
{
    for (int i = 0; i < ALP_SIZE; i++)
        if (root->children[i])
            return false;
    return true;
}
string deleteResult;
TrieNode* remove(TrieNode* root, string key, int depth = 0)
{
    // If tree is empty
    if (!root){
        if(depth==1){deleteResult="noRecord";}
        else{deleteResult="incorrect";}
        return NULL;
    }

    // If last character of key is being processed
    if (depth == key.size()) {

        // This node is no more end of word after
        // removal of given key
        if (root->isEndOfWord){
            root->isEndOfWord = false;
            deleteResult = "success";
        }
        else{deleteResult = "notEnough";}

        // If given is not prefix of any other word
        if (isEmpty(root)) {
            delete (root);
            root = NULL;
        }

        return root;
    }

    // If not last character, recur for the child
    // obtained using ASCII value
    int index = key[depth] - 'a';
    root->children[index] =
            remove(root->children[index], key, depth + 1);

    // If root does not have any child (its only child got
    // deleted), and it is not end of another word.
    if (isEmpty(root) && !root->isEndOfWord) {
        delete (root);
        root = NULL;
    }

    return root;
}


void display(struct TrieNode* root, char str[], int level)
{
    // If node is leaf node, it indicates end
    // of string, so a null character is added
    // and string is displayed
    if (root->isEndOfWord)
    {
        str[level] = '\0';
        output.append(str);output.append("(");output.append(root->english);output.append(")");output.append("\n");
    }

    int i;
    for (i = 0; i < ALP_SIZE; i++)
    {
        // if NON NULL child is found
        // add parent key to str and
        // call the display function recursively
        // for child node
        if (root->children[i])
        {
            str[level] = i + 'a';
            display(root->children[i], str, level + 1);
        }
    }
}

int main(int argc, char *argv[]) {
    ofstream deren;
    deren.open(argv[2]);
    struct TrieNode* root = getNode();
    ifstream readIO;
    char strr[50];
    string line;
    readIO.open(argv[1]);
    while(getline(readIO,line)){
        string command = line.substr(0,2);
        if(command=="in"){
            string arguments = line.substr(line.find("(")+1,line.find(")")-7);
            string inserted = arguments.substr(0,arguments.find(","));
            string insertResult = insert(root,arguments.substr(0,arguments.find(",")),arguments.substr(arguments.find(",")+1));
            if(insertResult=="success"){
                output += "\"" + inserted + "\" was added\n";
            }
            else if(insertResult=="already"){
                output += "\"" + inserted + "\" already exist\n";
            }
            else if(insertResult=="updated"){
                output += "\"" + inserted + "\" was updated\n";
            }
        } else if (command=="se"){
            string arguments = line.substr(line.find("(")+1,line.find(")")-7);
            string result = search(root,arguments);
            if(result=="noRecord"){
                output += "\"no record\"\n";
            }
            else if (result=="notEnough"){
                output += "\"not enough Dothraki word\"\n";
            }
            else if (result=="incorrect"){
                output += "\"incorrect Dothraki word\"\n";
            }
            else{
                output += "\"The English equivalent is ";
                output += result + "\"";
                output += "\n";
            }
        }
        else if (command=="li"){
            display(root,strr,0);
        } else if (command=="de"){
            string arguments = line.substr(line.find("(")+1,line.find(")")-7);
            remove(root,arguments);
            if(deleteResult=="noRecord"){
                output += "\"no record\"\n";
            }
            else if (deleteResult=="notEnough"){
                output += "\"not enough Dothraki word\"\n";
            }
            else if (deleteResult=="incorrect"){
                output += "\"incorrect Dothraki word\"\n";
            }
            else{
                output += "\"" + arguments + "\" deletion is successful\n";
            }
        }
    }
    deren << output;
    readIO.close();
    deren.close();
}
