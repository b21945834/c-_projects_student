//
// Created by 90543 on 15.12.2021.
//

#ifndef ASSIGNMENT3_STACK_H
#define ASSIGNMENT3_STACK_H


#include <string>

using namespace std;

class Stack {
    int top;
public:
    Stack(){top=-1;}
    string stack[200];
    void push(string ch);
    string pop();
    string peek();
    bool isEmpty();
    string stackPrint();
};


#endif //ASSIGNMENT3_STACK_H
