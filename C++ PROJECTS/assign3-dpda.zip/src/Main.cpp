#include <iostream>
#include <algorithm>
#include "fstream"
#include "vector"
#include "sstream"
#include "Stack.h"
using namespace std;

bool noProblem= true;
string output;

//LISTS OF INPUTS I GOT FROM THE DPDA FILE.
vector<string> possibleStates;
vector<string> finalStates;
vector<string> inputAlphabet;
vector<string> stackAlphabet;

//IF ONE OF INPUT IS INVALID ACCORDING TO POSSIBLE STATES OR STACK ALPHABET,
//THAT FUNCTION MAKES OUTPUT STRING ERROR CODE.
void invalidDPDA(){
    noProblem= false;
    output = "Error [1]:DPDA description is invalid!";
}

//FOR TRANSITION RULES I GOT FROM DPDA FILE,
//IN ORDER TO MAKE THEM AN OBJECT, I DEFINED A CLASS.
class TransitionRule{
public:
    string state,read,pop,nextState,push;
    TransitionRule(vector<string> rule){
        this->state = rule[0];
        this->read = rule[1];
        this->pop = rule[2];
        this->nextState = rule[3];
        this->push = rule[4];
    }
};
//TO STORAGE ALL TRANSITION RULES
vector<TransitionRule> transitionRules;
//TO STORAGE NEXT TRANSITION RULE ACCORDING TO INITIAL INPUT.
vector<TransitionRule> possibleTransitions;

Stack stack = Stack();

/*FOR INITIAL INPUT THAT READ FROM INPUT FILE,
IT ITERATES ALL TRANSITION RULES AND LOOK FOR APPROPRIATE TRANSITION RULE*/
void setPossibleTransitions(string initialState,string initialRead, string initialTop){
    for (int i = 0; i < transitionRules.size(); ++i) {
        if (transitionRules[i].state == initialState){
            if(transitionRules[i].read == initialRead){
                if(transitionRules[i].pop == initialTop){
                    possibleTransitions.push_back(transitionRules[i]);
                }
                else if (transitionRules[i].pop == "e" || transitionRules[i].pop == "$"){
                    possibleTransitions.push_back(transitionRules[i]);
                }
            }
            else if (transitionRules[i].read == "e"){
                if(transitionRules[i].pop == initialTop){
                    possibleTransitions.push_back(transitionRules[i]);
                }
                else if (transitionRules[i].pop == "e" || transitionRules[i].pop == "$"){
                    possibleTransitions.push_back(transitionRules[i]);
                }
            }
        }
    }
}

/*CHECKS THAT IF LAST STEP IS FINAL AND IS STACK EMPTY*/
bool checkAccept(string ifFinalState){
    if(count(finalStates.begin(),finalStates.end(),ifFinalState)!=0){
        if(stack.isEmpty()){
            return true;
        }else{return false;}
    } else{return false;}
}

/*IF THE READ ELEMENT,TO BE POPPED AND TO BE PUSHED ELEMENT ARE THE SAME
ACCORDING TO TRANSITION RULE, WE SHOULD PUSH THAT ELEMENT SOMEHOW.
 THAT FUNCTION UPDATES POSSIBLE TRANSITION RULE ACCORDING TO INITIAL INPUT.*/
void setPossibleSpecial(string nextState,string toBePushed){
    for (int i = 0; i < transitionRules.size(); ++i) {
        if(transitionRules[i].state==nextState){
            if(transitionRules[i].read=="e"){
                if(transitionRules[i].pop=="e"){
                    if(transitionRules[i].push== toBePushed){
                        possibleTransitions.push_back(transitionRules[i]);
                    }
                }
            }
        }
    }
}


int main(int argc, char *argv[]) {
    ifstream dpda;
    ofstream out;
    out.open(argv[3]);
    string line;
    dpda.open(argv[1]);
    string startState;
    if(dpda.is_open()){
        //I START TO READ DPDA RULES FILE.
        while(getline(dpda,line)){
            string temp;
            string command = line.substr(0,2);
            if(command == "Q:"){
                //BELOW HERE IS SPLITTING SET OF STATES LINE OF DPDA RULES FILE
                //AND PUSHING THEM LISTS.
                line = line.substr(2,line.length()-2);
                temp = line.substr(0,line.find(" => "));
                temp.append(",");
                size_t pos = 0;
                while ((pos = temp.find(",")) != string::npos) {
                    possibleStates.push_back(temp.substr(0, pos));
                    temp.erase(0, pos + 1);
                }
                temp = line.substr(line.find(" => ")+4);
                string one;
                temp.append(",");
                pos = 0;
                while ((pos = temp.find(",")) != string::npos) {
                    one = temp.substr(0, pos);
                    if(one.substr(0,1) == "("){
                        startState = one.substr(1,one.find(")")-1);
                    }
                    else if(one.substr(0,1)=="["){
                        finalStates.push_back(one.substr(1,one.find("]")-1));
                    }
                    temp.erase(0, pos + 1);
                }
            }
            else if(command == "A:"){
                //BELOW HERE IS READING VALID INPUT CHARACTERS LINE AND
                //STORAGE THEM IN A LIST.
                line = line.substr(2,line.length()-2);
                line.append(",");
                size_t pos = 0;
                while ((pos = line.find(",")) != string::npos) {
                    inputAlphabet.push_back(line.substr(0, pos));
                    line.erase(0, pos + 1);
                }
                inputAlphabet.push_back("e");
            }
            else if(command == "Z:"){
                //BELOW HERE IS READING VALID STACK ALPHABET.
                line = line.substr(2,line.length()-2);
                line.append(",");
                size_t pos = 0;
                while ((pos = line.find(",")) != string::npos) {
                    stackAlphabet.push_back(line.substr(0, pos));
                    line.erase(0, pos + 1);
                }
                stackAlphabet.push_back("e");
            }
            else if(command == "T:"){
                /*BELOW HERE, I WANTED TO:
                 1) READ WHOLE RULE AND SPLIT THEM
                 2) IF SOMETHING WRONG WITH RULE, I EXIT PROGRAM
                 3) IF NOT, I CREATED TRANSITION OBJECTS
                 4) STORED THEM IN A LIST.
                 */
                vector<string> transitionString;
                line = line.substr(2,line.length()-2);
                line.append(",");
                int sayac=1;
                size_t pos = 0;
                while ((pos = line.find(",")) != string::npos) {
                    if(sayac==1){
                        if(std::count(possibleStates.begin(),possibleStates.end(),line.substr(0,pos))==0){
                            invalidDPDA();
                            out<<output;
                            out.close();
                            return(0);
                        }
                    }
                    else if(sayac==2){
                        if(std::count(inputAlphabet.begin(),inputAlphabet.end(),line.substr(0,pos))==0){
                            invalidDPDA();
                            out<<output;
                            out.close();
                            return(0);
                        }
                    }
                    else if(sayac==3){
                        if(std::count(stackAlphabet.begin(),stackAlphabet.end(),line.substr(0,pos))==0){
                            invalidDPDA();
                            out<<output;
                            out.close();
                            return(0);
                        }
                    }
                    else if(sayac==4){
                        if(std::count(possibleStates.begin(),possibleStates.end(),line.substr(0,pos))==0){
                            invalidDPDA();
                            out<<output;
                            out.close();
                            return(0);
                        }
                    }
                    else if(sayac==5){
                        if(std::count(stackAlphabet.begin(),stackAlphabet.end(),line.substr(0,pos))==0){
                            invalidDPDA();
                            out<<output;
                            out.close();
                            return(0);
                        }
                    }
                    transitionString.push_back(line.substr(0, pos));
                    line.erase(0, pos + 1);
                    sayac +=1;
                }
                TransitionRule t = TransitionRule(transitionString);
                transitionRules.push_back(t);
            }
        }
    dpda.close();
    }
    ifstream input;
    string inputLine;
    input.open(argv[2]);

    if(input.is_open()){
        string initialState;
        string initialRead;
        string initialTop;
        string initialNext;
        string initialPush;
        while(getline(input,inputLine)){
            //I START TO READ INPUT FILE LINE BY LINE AND SPLIT THEM.

            stack = Stack();
            vector<string> inputs;
            if(inputLine.substr(inputLine.length()-1)=="\r"){
                inputLine = inputLine.substr(0,inputLine.length()-1);
            }
            inputLine.append(",");
            size_t pos = 0;
            while ((pos = inputLine.find(",")) != string::npos) {
                inputs.push_back(inputLine.substr(0, pos));
                inputLine.erase(0, pos + 1);
            }
            int inputSayac=0;
            //I SET THE FIRST TRANSITION RULE I AM GOING IN TO.
            setPossibleTransitions(startState,inputs[0],stack.peek());

            while(!possibleTransitions.empty()){
                bool wentBack=false;
                TransitionRule initialTransition = possibleTransitions[0];
                initialState = initialTransition.state;
                initialRead = initialTransition.read;
                initialTop = initialTransition.pop;
                initialNext = initialTransition.nextState;
                initialPush = initialTransition.push;
                if(initialRead != "e"){
                    inputSayac += 1;
                }
                if(initialTop != "e"){
                    stack.pop();
                }
                if(initialPush != "e"){
                    stack.push(initialPush);
                }
                if(initialRead==initialTop && initialTop == initialPush){
                    wentBack=true;
                }
                output += initialState + "," + initialRead + "," + initialTop + " => " + initialNext + "," + initialPush;
                output.append(stack.stackPrint());
                output.append("\n");
                possibleTransitions.clear();
                if(wentBack){
                    setPossibleSpecial(initialNext,initialPush);
                }
                else if(inputSayac==inputs.size() && stack.isEmpty()){
                    setPossibleTransitions(initialNext,"e",stack.peek());
                }
                else if(inputSayac!=inputs.size()){
                    setPossibleTransitions(initialNext,inputs[inputSayac],stack.peek());
                }
            }
            if(checkAccept(initialNext)){
                output.append("ACCEPT\n\n");
            } else{
                output.append("REJECT\n\n");
            }
        }
        input.close();
    }
    out<<output;
    out.close();
}
