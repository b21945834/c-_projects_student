//
// Created by 90543 on 15.12.2021.
//

#include "Stack.h"

using namespace std;

void Stack::push(string ch) {
    top++;
    stack[top] = ch;
}

string Stack::pop() {
    string popped;
    if(top>=0){
        popped = stack[top];
        top--;
    }
    return popped;
}

string Stack::peek() {
    string topOfList;
    string empty = "e";
    string specialCharacter = "$";
    if(top>0){
        topOfList = stack[top];
        return topOfList;
    }
    else if(top==0){
        if(stack[top] == specialCharacter){
            return empty;
        }
        else{
            return stack[0];
        }
    }
    else{
        return "e";
    }
}

bool Stack::isEmpty() {
    if(top==-1){
        return true;
    }
    else if (top==0 && stack[top] == "$"){
        return true;
    }
    else{
        return false;
    }
}

string Stack::stackPrint() {
    string toBeAppended = "[STACK]:";
    if(top==-1){
        return toBeAppended;
    }
    else{
        for (int i = 0; i <= top; ++i) {
            if(i==top){
                toBeAppended.append(stack[i]);
            }
            else{
                toBeAppended.append(stack[i]);
                toBeAppended.append(",");
            }
        }
        return toBeAppended;
    }
}
